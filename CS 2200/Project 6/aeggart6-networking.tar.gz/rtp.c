#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "rtp.h"

/* GIVEN Function:
 * Handles creating the client's socket and determining the correct
 * information to communicate to the remote server
 */
CONN_INFO* setup_socket(char *ip, char *port){
	struct addrinfo *connections, *conn = NULL;
	struct addrinfo info;
	memset(&info, 0, sizeof(struct addrinfo));
	int sock = 0;

	info.ai_family = AF_INET;
	info.ai_socktype = SOCK_DGRAM;
	info.ai_protocol = IPPROTO_UDP;
	getaddrinfo(ip, port, &info, &connections);

	/*for loop to determine corr addr info*/
	for(conn = connections; conn != NULL; conn = conn->ai_next){
		sock = socket(conn->ai_family, conn->ai_socktype, conn->ai_protocol);
		if (sock < 0) {
			#ifdef DEBUG
				perror("Failed to create socket\n");
			#endif
			continue;
		}
		#ifdef DEBUG
			printf("Created a socket to use.\n");
		#endif
		break;
	}
	if(conn == NULL){
		perror("Failed to find and bind a socket\n");
		return NULL;
	}
	CONN_INFO* conn_info = malloc(sizeof(CONN_INFO));
	conn_info->socket = sock;
	conn_info->remote_addr = conn->ai_addr;
	conn_info->addrlen = conn->ai_addrlen;
	return conn_info;
}

void shutdown_socket(CONN_INFO *connection){
	if(connection)
		close(connection->socket);
}

/* 
 * ===========================================================================
 *
 *			STUDENT CODE STARTS HERE. PLEASE COMPLETE ALL FIXMES
 *
 * ===========================================================================
*/


/*
 *  Returns a number computed based on the data in the buffer.
*/
static int checksum(const char *buffer, int length){

	int sum = 0;

	for(int i = 0; i < length; i++){ 			//Iterate through array and sum ascii chars
		sum = sum + (int) buffer[i];
	}
	/*  
	 *
	 *  The goal is to return a number that is determined by the contents
	 *  of the buffer passed in as a parameter.  There a multitude of ways
	 *  to implement this function.  For simplicity, simply sum the ascii
	 *  values of all the characters in the buffer, and return the total.
	*/

	return sum;
}

/*
 *  Converts the given buffer into an array of PACKETs and returns
 *  the array.  The value of (*count) should be updated so that it 
 *  contains the length of the array created.
 */
static PACKET* packetize(const char *buffer, int length, int *count){

	int num = 0;										//num of packets
	PACKET *packet_arr;

	if(length % MAX_PAYLOAD_LENGTH == 0){
		num = length/MAX_PAYLOAD_LENGTH;
	}else{
		num = length/MAX_PAYLOAD_LENGTH + 1;
	}
	packet_arr = malloc((sizeof(PACKET) * (size_t)num));

	for(int i = 0; i < num; i++){
		if(i != num - 1){								//If not last packet
			//memcpy(packet_arr[i].payload, &buffer[i * MAX_PAYLOAD_LENGTH], MAX_PAYLOAD_LENGTH);
			packet_arr[i].payload_length = MAX_PAYLOAD_LENGTH;
			packet_arr[i].type = DATA;
		}else{
			//memcpy(packet_arr[i].payload, &buffer[i * MAX_PAYLOAD_LENGTH], (size_t)(length % MAX_PAYLOAD_LENGTH));
			packet_arr[i].payload_length = length % MAX_PAYLOAD_LENGTH;		//Maybe right
			packet_arr[i].type = LAST_DATA;
		}

		for(int j = 0; j<packet_arr[i].payload_length; j++){
			packet_arr[i].payload[j] =buffer[i * MAX_PAYLOAD_LENGTH + j];
		}
		packet_arr[i].checksum = checksum(packet_arr[i].payload, packet_arr[i].payload_length);
	}

	/*  
	 *  The goal is to turn the buffer into an array of packets.
	 *  You should allocate the space for an array of packets and
	 *  return a pointer to the first element in that array.  Each 
	 *  packet's type should be set to DATA except the last, as it 
	 *  should be LAST_DATA type. The integer pointed to by 'count' 
	 *  should be updated to indicate the number of packets in the 
	 *  array.
	*/

	*count = num;
	return packet_arr;
}

/*
 * Send a message via RTP using the connection information
 * given on UDP socket functions sendto() and recvfrom()
 */
int rtp_send_message(CONN_INFO *connection, MESSAGE *msg){
		
	int count = 0;
	PACKET *packet_arr = packetize(msg->buffer, msg->length, &count);
	PACKET *resp = malloc(sizeof(PACKET));

	int i = 0;
	while (i < count){
		sendto(connection-> socket, &packet_arr[i], sizeof(PACKET), 0, connection->remote_addr, connection->addrlen);
		recvfrom(connection->socket, resp, sizeof(PACKET), 0, connection->remote_addr, &connection->addrlen);
		if(resp->type == ACK){
			i++;
		}
	}

	/* 
	 * The goal of this function is to turn the message buffer
	 * into packets and then, using stop-n-wait RTP protocol,
	 * send the packets and re-send if the response is a NACK.
	 * If the response is an ACK, then you may send the next one
	*/

	return 1;
}

/*
 * Receive a message via RTP using the connection information
 * given on UDP socket functions sendto() and recvfrom()
 */
MESSAGE* rtp_receive_message(CONN_INFO *connection){

	int chksum;
	MESSAGE *message;
	message = malloc(sizeof(MESSAGE));
	PACKET *resp;
	resp = malloc(sizeof(PACKET));
	PACKET *pack;
	pack = malloc(sizeof(PACKET));

	do{
		recvfrom(connection->socket, pack, sizeof(PACKET), 0, connection->remote_addr, &connection->addrlen);
		if(pack->type == LAST_DATA || pack->type == DATA){
			chksum = checksum(pack->payload, pack->payload_length);
			if (chksum == pack->checksum){
				resp->type = ACK;
				sendto(connection->socket, resp, sizeof(PACKET), 0, connection->remote_addr, connection->addrlen);
				char* temp = malloc((sizeof(char)*pack->payload_length + sizeof(char)*message->length));			
				memcpy(temp, message->buffer, message->length);
				memcpy(temp + message->length, pack->payload, pack->payload_length);
				message->buffer = temp;
				message->length = message->length + pack->payload_length;

			}else{
				resp->type = NACK;
				sendto(connection->socket, resp, sizeof(PACKET), 0, connection->remote_addr, connection->addrlen);
	
			}

		}
	} while (pack->type != LAST_DATA || resp->type != ACK);

	/* 
	 * The goal of this function is to handle 
	 * receiving a message from the remote server using
	 * recvfrom and the connection info given. You must 
	 * dynamically resize a buffer as you receive a packet
	 * and only add it to the message if the data is considered
	 * valid. The function should return the full message, so it
	 * must continue receiving packets and sending response 
	 * ACK/NACK packets until a LAST_DATA packet is successfully 
	 * received.
	*/
	return message;
}
