/*
 * student.c
 * Multithreaded OS Simulation for CS 2200
 *
 * This file contains the CPU scheduler for the simulation.
 */

#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "os-sim.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/** Function prototypes **/
extern void idle(unsigned int cpu_id);
extern void preempt(unsigned int cpu_id);
extern void yield(unsigned int cpu_id);
extern void terminate(unsigned int cpu_id);
extern void wake_up(pcb_t *process);


/*
 * current[] is an array of pointers to the currently running processes.
 * There is one array element corresponding to each CPU in the simulation.
 *
 * current[] should be updated by schedule() each time a process is scheduled
 * on a CPU.  Since the current[] array is accessed by multiple threads, you
 * will need to use a mutex to protect it.  current_mutex has been provided
 * for your use.
 */
static pcb_t **current;
static pthread_mutex_t current_mutex;

static pthread_mutex_t ready_mutex;		//Mutex for ready queue
static pthread_cond_t not_idle_cond;	//Not idle condition

typedef struct {
	pcb_t *proc;			//Pointer to current process
	pcb_t *next;			//Pointer to next process in list
}linked_list;

static linked_list *ready_queue;		//Linked list for ready queue				
static int timeslice;					//Timeslice used in Round Robin
static int scheduler_type;				//FIFO=0, RoundRobin=1, SRTF=2
static int cpu_num;


//Adds a process to the ready Queue
static void add_ready(pcb_t *process){
	pcb_t* last;
	pthread_mutex_lock(&ready_mutex);			//Lock the ready queue

	if(ready_queue->proc == NULL){							//If the ready queue is empty
		ready_queue->proc = process;
	}else{
		last = ready_queue->proc;
		while(last->next != NULL)				//Iterate through ready queue until you find the end
			last = last->next;
		last->next = process;
	}

	pthread_cond_signal(&not_idle_cond);		//Send out signal
	pthread_mutex_unlock(&ready_mutex);			//Unlock the ready queue	

}

static pcb_t* get_first(){
	pcb_t* head = ready_queue->proc;

	pthread_mutex_lock(&ready_mutex);			//Lock ready queue
	if(head == NULL){							//If ready queue is empty
		pthread_mutex_unlock(&ready_mutex);\
		return NULL;
	}else{
		ready_queue->proc = head->next;
	}
	head->next = NULL;
	pthread_mutex_unlock(&ready_mutex);			//Unlock ready queue
	return head;

}

static pcb_t* get_least_time(){
	pcb_t* temp;
	pcb_t* temp_prev = NULL;
	pcb_t* least_time = ready_queue->proc;
	pcb_t* least_time_prev = NULL;

	pthread_mutex_lock(&ready_mutex);				//Lock ready queue
	if(least_time == NULL){							//If ready queue is empty
		pthread_mutex_unlock(&ready_mutex);
		return NULL;
	}else{
		temp = least_time;
		while(temp->next != NULL){
			if(temp->time_remaining < least_time->time_remaining){
				least_time = temp;
				least_time_prev = temp_prev;
			}
			temp_prev = temp;
			temp = temp->next;
		}
		if(least_time == ready_queue->proc){		//If the least time was the head
			ready_queue->proc = least_time->next;
		}else{										//If the least time was in the middle of the list
			least_time_prev->next = least_time->next;
		}
	}
	least_time->next = NULL;
	pthread_mutex_unlock(&ready_mutex);				//Unlock ready queue
	return least_time;

}

/*
 * schedule() is your CPU scheduler.  It should perform the following tasks:
 *
 *   1. Select and remove a runnable process from your ready queue which 
 *	you will have to implement with a linked list or something of the sort.
 *
 *   2. Set the process state to RUNNING
 *
 *   3. Call context_switch(), to tell the simulator which process to execute
 *      next on the CPU.  If no process is runnable, call context_switch()
 *      with a pointer to NULL to select the idle process.
 *	The current array (see above) is how you access the currently running process indexed by the cpu id. 
 *	See above for full description.
 *	context_switch() is prototyped in os-sim.h. Look there for more information 
 *	about it and its parameters.
 */
static void schedule(unsigned int cpu_id)
{
	pcb_t* proc;

	if (scheduler_type == 2){
		proc = get_least_time();
	}else{
		proc = get_first();
	}
	pthread_mutex_lock(&current_mutex);	
    
	if(proc != NULL){
		proc->state = PROCESS_RUNNING;
	}
	context_switch(cpu_id, proc, timeslice);
	current[cpu_id] = proc;
	pthread_mutex_unlock(&current_mutex);
}


/*
 * idle() is your idle process.  It is called by the simulator when the idle
 * process is scheduled.
 *
 * This function should block until a process is added to your ready queue.
 * It should then call schedule() to select the process to run on the CPU.
 */
extern void idle(unsigned int cpu_id)
{
	pthread_mutex_lock(&current_mutex);		//Lock current	
	while(ready_queue->proc == NULL){
		pthread_cond_wait(&not_idle_cond,&current_mutex);	//Wait for something in ready queue
	}
	pthread_mutex_unlock(&current_mutex);	//Unlock current
    schedule(cpu_id);

    /*
     * REMOVE THE LINE BELOW AFTER IMPLEMENTING IDLE()
     *
     * idle() must block when the ready queue is empty, or else the CPU threads
     * will spin in a loop.  Until a ready queue is implemented, we'll put the
     * thread to sleep to keep it from consuming 100% of the CPU time.  Once
     * you implement a proper idle() function using a condition variable,
     * remove the call to mt_safe_usleep() below.
     */
    //mt_safe_usleep(1000000);
}


/*
 * preempt() is the handler called by the simulator when a process is
 * preempted due to its timeslice expiring.
 *
 * This function should place the currently running process back in the
 * ready queue, and call schedule() to select a new runnable process.
 *
 * Remember to set the status of the process to the proper value.
 */
extern void preempt(unsigned int cpu_id)
{
    pthread_mutex_lock(&current_mutex);			//Lock current
	current[cpu_id]->state = PROCESS_READY;
	add_ready(current[cpu_id]);
	pthread_mutex_unlock(&current_mutex);		//Unlock current
	schedule(cpu_id);							//Schedule the next process
	
}


/*
 * yield() is the handler called by the simulator when a process yields the
 * CPU to perform an I/O request.
 *
 * It should mark the process as WAITING, then call schedule() to select
 * a new process for the CPU.
 */
extern void yield(unsigned int cpu_id)
{
    pthread_mutex_lock(&current_mutex);				//Lock current
	current[cpu_id]->state = PROCESS_WAITING;		//Set the correct process's state to waiting
	pthread_mutex_unlock(&current_mutex);			//Unlock current
	schedule(cpu_id);								//Schedule new process


}


/*
 * terminate() is the handler called by the simulator when a process completes.
 * It should mark the process as terminated, then call schedule() to select
 * a new process for the CPU.
 */
extern void terminate(unsigned int cpu_id)
{
    pthread_mutex_lock(&current_mutex);					//Lock current
	current[cpu_id]->state = PROCESS_TERMINATED;		//Terminate the correct process on the right CPU
	pthread_mutex_unlock(&current_mutex);				//Unlock current
	schedule(cpu_id);									//Schedule a new process
}


/*
 * wake_up() is the handler called by the simulator when a process's I/O
 * request completes.  It should perform the following tasks:
 *
 *   1. Mark the process as READY, and insert it into the ready queue.
 *
 *   2. If the scheduling algorithm is SRTF, wake_up() may need
 *      to preempt the CPU with the highest remaining time left to allow it to
 *      execute the process which just woke up.  However, if any CPU is
 *      currently running idle, or all of the CPUs are running processes
 *      with a lower remaining time left than the one which just woke up, wake_up()
 *      should not preempt any CPUs.
 *	To preempt a process, use force_preempt(). Look in os-sim.h for 
 * 	its prototype and the parameters it takes in.
 */
extern void wake_up(pcb_t *process)
{
	unsigned int most_time = 0;
	int cpu_id = -1;
	
	process->state = PROCESS_READY;				//Set state to process ready
	add_ready(process);							//Add the process to the queue
	if(scheduler_type == 2){					//If scheduler is SRTF
		pthread_mutex_lock(&current_mutex);		//Lock current 
		for(int i = 0; i < cpu_num; i++){		//For all the current processes
			if(current[i]!=NULL && current[i]->time_remaining>most_time){
				most_time = current[i]->time_remaining;
				cpu_id = i;
			}	
		}
		pthread_mutex_unlock(&current_mutex);	//Unlock current
		//If all cpu had a process running and proc has a shorter time than longet running proc
		if(cpu_id != -1 && process->time_remaining < most_time){				
			force_preempt((unsigned int)cpu_id);				
		}	
	}  
}


/*
 * main() simply parses command line arguments, then calls start_simulator().
 * You will need to modify it to support the -r and -s command-line parameters.
 */
int main(int argc, char *argv[])
{
    unsigned int cpu_count;

    /* Parse command-line arguments */
    if (argc < 2 || argc > 4)
    {
        fprintf(stderr, "CS 2200 Project 4 -- Multithreaded OS Simulator\n"
            "Usage: ./os-sim <# CPUs> [ -r <time slice> | -s ]\n"
            "    Default : FIFO Scheduler\n"
            "         -r : Round-Robin Scheduler\n"
            "         -s : Shortest Remaining Time First Scheduler\n\n");
        return -1;
    }
    cpu_count = strtoul(argv[1], NULL, 0);
	cpu_num = (int)cpu_count;

    /* FIX ME - Add support for -r and -s parameters*/
	if(argc == 4 && !strcmp(argv[2],"-r")){																	//Needs to be fixed probably
		printf("Round Robin Scheduler\n");
		scheduler_type = 1;
		timeslice = atoi(argv[3]);
	}else if(argc == 3 && !strcmp(argv[2],"-s")){
		printf("SRTF Scheduler\n");
		scheduler_type = 2;
	}else{
		printf("FIFO Scheduler\n");
		scheduler_type = 0;
	}


    /* Allocate the current[] array and its mutex */
    current = malloc(sizeof(pcb_t*) * cpu_count);
    assert(current != NULL);
	ready_queue = malloc(sizeof(linked_list));
	assert(ready_queue != NULL);

    pthread_mutex_init(&current_mutex, NULL);
	pthread_mutex_init(&ready_mutex, NULL);
	pthread_cond_init(&not_idle_cond, NULL);

    /* Start the simulator in the library */
    start_simulator(cpu_count);

    return 0;
}


#pragma GCC diagnostic pop
